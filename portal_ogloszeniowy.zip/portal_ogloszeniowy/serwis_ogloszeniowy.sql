-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Cze 06, 2025 at 12:12 AM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serwis_ogloszeniowy`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `annoucments`
--

CREATE TABLE `annoucments` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `description` varchar(50) NOT NULL,
  `contents` varchar(300) NOT NULL,
  `img` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `annoucments`
--

INSERT INTO `annoucments` (`id`, `id_user`, `title`, `description`, `contents`, `img`) VALUES
(1, 1, 'Rower', 'Nowy rower został odnaleziony dzisiaj w lesie', 'W lesie dzisiejszego dnia został odnaleziony czerwony rower marki Revoult!!!', '../img/img_users/Png(1).png'),
(2, 1, 'Nowy haker', 'Nowy haker został znaleziony w mieście', 'W mieście policja zlokalizowała nowego hakera zwanego Fiodar', '../img/img_users/profilowetiktok.png'),
(3, 2, 'Nowy komputer', 'Sprzedam nowy komputer', 'Dzisiaj mój syn skończył grać na komputerze', '../img/brak_zdjecia.png'),
(4, 1, 'Yeat', 'Yeat został znaleziony w oficjalnie w lesie!!!!!!!', 'Dzisiaj w nocy Yeat został znaleziony w lesie w mieście pod Zaborem i ma nadzieję walczyć do konća w szpiatlu', '../img/img_users/Png (2).png');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `login` varchar(15) NOT NULL,
  `password` varchar(70) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role` enum('user','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `name`, `surname`, `login`, `password`, `email`, `role`) VALUES
(1, 'Remigiusz', 'Ganda', 'Remek', '$2y$10$LhTxPmWhkFfljV6ptdPut.0RxjIyKYImxDAJMg7/4fQgBUINGypua', 'remik.ganda@gmail.com', 'user'),
(2, 'Andrzej', 'Rudy', 'Andrzejrudy69', '$2y$10$YoAISqzhjqfW7JROCStkxO.LEG.6cSJBQL8WjRG45Vg2wCord2Ne2', 'AndrzejRudy@gmail.com', 'user');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `annoucments`
--
ALTER TABLE `annoucments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user_FK` (`id_user`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `login_unique` (`login`),
  ADD UNIQUE KEY `email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `annoucments`
--
ALTER TABLE `annoucments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `annoucments`
--
ALTER TABLE `annoucments`
  ADD CONSTRAINT `id_user_FK` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
